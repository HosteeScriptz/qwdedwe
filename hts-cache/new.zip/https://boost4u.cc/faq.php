<!DOCTYPE html>
<html>
  <head>
    <title>FAQ</title>
    

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Onest:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="normalize.css">
  	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.css" />
    <link rel="stylesheet" href="global.css?t=1724163908">
    <link rel="stylesheet" href="responsive.css?t=1724163908">


    <link rel="icon" type="image/png" href="images/favicon.png?t=1713474191">
    <meta property="og:title" content="Boost4u - Automated Cheap Discord Boosts">
    <meta property="og:description" content="Boost4u, your ultimate destination for unleashing the full potential of your Discord server! Introducing our cutting-edge Nitro Tokens and Server Boosting service, designed to elevate your Discord experience to new heights.">
    <meta property="og:image" content="images/favicon.png?t=1724163908">

     <meta name="viewport" content="width=device-width, initial-scale=1">

 <script src="https://cdn.sellix.io/static/js/embed.js"></script>
 <link href="https://unpkg.com/aos@2.3.1/dist/aos2.css" rel="stylesheet">

	
  </head>
  <body class="bg_primary color_primary">


    
<header class="pt_6 pb_6">
  <div class="container flex_container items_center button_outlined no_hover ignore_hover radius_large pt_6 pb_6 pl_8 pr_8">
     <a href="index.php" class="logo theme_text_gradient weight_semibold"><img src="images/logo.png?t=1724163908" data-width="160px" /></a>
     <a href="javascript:;" data-menu="#nav_menu" class="nav_button float_right none mt_1">☰</a>
      <nav id="nav_menu" data-remove-class="navigation pl_4 ml_4 flex_full align_center" data-extra-classes="dropdown_menu menu z_index none align_left position_absolute radius_medium bg_secondary p_2" class="navigation align_center pl_4 ml_4 flex_full">
 
  
        <a href="index.php" class="pt_1 pb_1 pl_2 pr_2 ml_3 weight_semibold text_large">Home</a>
         <a href="index.php#about" class="pt_1 pb_1 pl_2 pr_2 ml_3 weight_semibold text_large">About</a>
		 <a href="faq.php" class="pt_1 pb_1 pl_2 pr_2 ml_3 weight_semibold text_large">FAQ</a>
		<a href="index.php#features" class="pt_1 pb_1 pl_2 pr_2 ml_3 weight_semibold text_large">Features</a>
		<a href="vouches.php" class="pt_1 pb_1 pl_2 pr_2 ml_3 weight_semibold text_large">Feedbacks</a>
		
	 </nav>
	 <div class="welcomeblock">
	    <a href="#products" class="pt_3 pb_3 pl_6 pr_6 ml_5 radius_large button_solid text_large"><span class="weight_semibold color_white">Products</span></a>
	 
	 </div>
	

</div>
</header> 






 <section class="bg_products" id="reviews">
   <div class="container pt p_6 mt_12">
     <div class="text_4xlarge align_center weight_semibold title_font mb_8 pb_8">Frequently Asked Questions</div>

	 <div class="mb_8 pb_8"></div>
	  <div class="mb_8 border border_bottom border_dark_gray pb_8">
<div class="text_xlarge weight_semibold " data-menu="#faq_1">
Can I get my server banned for using this?
</div>
		<div class="pt_4 pb_4" id="faq_1">No. Your server cannot get termed using our boosting service, as our service is 100% legal.</div>
	
	</div>
	
  <div class="mb_8 border border_bottom border_dark_gray pb_8">
<div class="text_xlarge weight_semibold " data-menu="#faq_2">
Why are your prices so cheap?
</div>
		<div class="pt_4 pb_4 none" id="faq_2"></div>
	Our prices are so cheap as we use private & unique methods to get cheaper discord server boosts, everything is following the law, so that we wont be doing any illegal action.
	</div>
	

  <div class="mb_8 border border_bottom border_dark_gray pb_8">
<div class="text_xlarge weight_semibold " data-menu="#faq_3">
Where can I contact you?
</div>
		<div class="pt_4 pb_4 none" id="faq_3">You can contact us via Discord or Telegram.</div>
	
	</div>
	

  <div class="mb_8 border border_bottom border_dark_gray pb_8">
<div class="text_xlarge weight_semibold " data-menu="#faq_4">
Why can't I pay with PayPal/Venmo/GiftCards on the website?
</div>
		<div class="pt_4 pb_4 none" id="faq_4">Actually, Venmo, PayPal & Giftcards are only being accepted opening a ticket in our Discord server.</div>
	
	</div>
	

  <div class="mb_8 border border_bottom border_dark_gray pb_8">
<div class="text_xlarge weight_semibold " data-menu="#faq_5">
How much time does it takes to get my server boosted?
</div>
		<div class="pt_4 pb_4 none" id="faq_5">Our service is fully automated! Your server will be boosted within 30 seconds after your payment has been confirmed.</div>
	
	</div>
	

  <div class="mb_8 border border_bottom border_dark_gray pb_8">
<div class="text_xlarge weight_semibold " data-menu="#faq_6">
I am having issues making a purchase. What can I do?
</div>
		<div class="pt_4 pb_4 none" id="faq_6">Please contact our Support Team available on our Discord Server. We will be with you to help with your order as soon possible.</div>
	
	</div>
	
  <div class="mb_8 border border_bottom border_dark_gray pb_8">
<div class="text_xlarge weight_semibold " data-menu="#faq_7">
My order went wrong! Where can I contact a support team to solve my issue?
</div>
		<div class="pt_4 pb_4 none" id="faq_7">You can contact us via Discord or Telegram.</div>
	
	</div>

	  
	   <div class="mb_8 pb_8"></div>
	  
	 </div>  
</section>



   
    

 <footer class="bg_tertiary" data-aos="fade-up">
 <div class="container pt_8 pb_8">
  
  <div class="flex_container">
     <div data-width="30%" class="color_neutral">
	     <div class="color_secondary text_large weight_semibold mb_4 logo"><img data-width="200px" src="images/logo.png?t=1724163908" /></div>
		    We are your professional contact since 2022 for cheap and very fast Discord services & co. Discover us now!
	 </div>
	 <div data-width="30%"></div>
     <div data-width="20%">
	 
	 <div class="weight_semibold">Resources</div>
	 <a href="#features" class="block mt_2 mb_2"><span class="color_neutral">Features</span></a>
	  <a href="#faq" class="block mt_2 mb_2"><span class="color_neutral">FAQ</span></a>
	 <a href="#products" class="block mt_2 mb_2"><span class="color_neutral">Products</span></a>
	 <a href="https://boost4u.cc/discord" target="_blank" class="block mt_2 mb_2"><span class="color_neutral">Discord</span></a>
	
	 
	 </div>
	   <div data-width="20%">
     <div class="weight_semibold">Other</div>
	 <a href="tos.php" class="block mt_2 mb_2"><span class="color_neutral">Terms of service</span></a>
	 <a href="#top" class="block mt_2 mb_2"><span class="color_neutral">Return to top</span></a>
	 <a href="#features" class="block mt_2 mb_2"><span class="color_neutral">Feedbacks</span></a>

	 
	 </div>
    
  </div>
  
		   
			
			
	
		
	
		  
		
				  
		</div>
   
   </div>
 
 
 <div class="mt_4 pt_4 border pb_4 border_dark_gray container">
   © 2024 <span class="theme_text_gradient">Boost4u</span>. All rights reserved.<br />
   We are not affiliate with Discord.com. 
   

 
 </div>
 </div>
 </footer>



   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
   <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

<script>
  AOS.init();
</script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.js"></script>
	<script src="general.js?t=1724163908"></script>





<script>(function(){function c(){var b=a.contentDocument||a.contentWindow.document;if(b){var d=b.createElement('script');d.innerHTML="window.__CF$cv$params={r:'8b630d0a5e4881b5',t:'MTcyNDE2MzkwOC4wMDAwMDA='};var a=document.createElement('script');a.nonce='';a.src='/cdn-cgi/challenge-platform/scripts/jsd/main.js';document.getElementsByTagName('head')[0].appendChild(a);";b.getElementsByTagName('head')[0].appendChild(d)}}if(document.body){var a=document.createElement('iframe');a.height=1;a.width=1;a.style.position='absolute';a.style.top=0;a.style.left=0;a.style.border='none';a.style.visibility='hidden';document.body.appendChild(a);if('loading'!==document.readyState)c();else if(window.addEventListener)document.addEventListener('DOMContentLoaded',c);else{var e=document.onreadystatechange||function(){};document.onreadystatechange=function(b){e(b);'loading'!==document.readyState&&(document.onreadystatechange=e,c())}}}})();</script></body>

</html>

  </body>
</html>
