<!DOCTYPE html>
<html>
  <head>
    <title> Terms of service</title>
    

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Onest:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="normalize.css">
  	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.css" />
    <link rel="stylesheet" href="global.css?t=1724163956">
    <link rel="stylesheet" href="responsive.css?t=1724163956">


    <link rel="icon" type="image/png" href="images/favicon.png?t=1713474191">
    <meta property="og:title" content="Boost4u - Automated Cheap Discord Boosts">
    <meta property="og:description" content="Boost4u, your ultimate destination for unleashing the full potential of your Discord server! Introducing our cutting-edge Nitro Tokens and Server Boosting service, designed to elevate your Discord experience to new heights.">
    <meta property="og:image" content="images/favicon.png?t=1724163956">

     <meta name="viewport" content="width=device-width, initial-scale=1">

 <script src="https://cdn.sellix.io/static/js/embed.js"></script>
 <link href="https://unpkg.com/aos@2.3.1/dist/aos2.css" rel="stylesheet">

	
  </head>
  <body class="bg_primary color_primary">


    
<header class="pt_6 pb_6">
  <div class="container flex_container items_center button_outlined no_hover ignore_hover radius_large pt_6 pb_6 pl_8 pr_8">
     <a href="index.php" class="logo theme_text_gradient weight_semibold"><img src="images/logo.png?t=1724163956" data-width="160px" /></a>
     <a href="javascript:;" data-menu="#nav_menu" class="nav_button float_right none mt_1">☰</a>
      <nav id="nav_menu" data-remove-class="navigation pl_4 ml_4 flex_full align_center" data-extra-classes="dropdown_menu menu z_index none align_left position_absolute radius_medium bg_secondary p_2" class="navigation align_center pl_4 ml_4 flex_full">
 
  
        <a href="index.php" class="pt_1 pb_1 pl_2 pr_2 ml_3 weight_semibold text_large">Home</a>
         <a href="index.php#about" class="pt_1 pb_1 pl_2 pr_2 ml_3 weight_semibold text_large">About</a>
		 <a href="faq.php" class="pt_1 pb_1 pl_2 pr_2 ml_3 weight_semibold text_large">FAQ</a>
		<a href="index.php#features" class="pt_1 pb_1 pl_2 pr_2 ml_3 weight_semibold text_large">Features</a>
		<a href="vouches.php" class="pt_1 pb_1 pl_2 pr_2 ml_3 weight_semibold text_large">Feedbacks</a>
		
	 </nav>
	 <div class="welcomeblock">
	    <a href="#products" class="pt_3 pb_3 pl_6 pr_6 ml_5 radius_large button_solid text_large"><span class="weight_semibold color_white">Products</span></a>
	 
	 </div>
	

</div>
</header> 







<section class="bg_products">
   <div class="container pt p_6 mt_12">
     <div class="text_4xlarge align_center weight_semibold title_font mb_8 pb_8">Boost4u Store Terms of Service</div>

	 <div class="mb_8 pb_8"></div>
  
  <div class="p_4 radius_medium bg_secondary" style="text-align: center;">

<strong>Boost4u Store Terms of Service</strong><br /><br />

We as "Boost4u" do not give refunds or replacements unless the problem comes from our side! If the problem comes from our side, you can contact support within 24h and let us check this whole issue. If you contact us outside of this time, you are out of luck.<br /><br />


<strong>Boosts TOS:</strong><br />
- We don't give any boost refund if the server should suddenly become unboosted or similar. <br />
- If the full runtime is not reached, we do not offer new boosts.<br /><br />

<strong>Tools TOS:</strong><br />
- If a tool does not work, has been patched or something similar, we will of course try to fix the problem. If the problem can not be fixed, you have had bad luck and unfortunately then tied your hands. We offer no warranty or return / refund.<br /><br />

<strong>Nitro TOS:</strong><br />
- Dont stack Nitros. If you have 2 or more nitro in credits, no warranty on that.<br />
- Our links are not getting autoclaimed 6hour warranty, if the link get autoclaimed you need to provide proof. So strictly no refund after 6h (if is isn’t indicated)<br /><br />

<strong>Token TOS:</strong><br />
- All tokens are checked with our checker before delivery and delivered according to it. From this point on, the full responsibility lies with the customer. We do not offer refunds or new tokens. If tokens have been used before and have a cooldown, we do not offer a warranty or refund. The tokens do <strong>NOT</strong> have to be delivered with Email:Pass, it can always vary. <br />
- If Discord revokes the Nitro of the Tokens we dont give any Refunds or Replacements. For all Token Deliverys we offer a 15 Minutes Warranty to get the Delivery. Also they got already checked by us before stocking. <br /><br />

<strong>Real Member TOS:</strong><br />
Our members are all 100% real members who have verified themselves to be pulled. This means that some will stay and some will leave the server. We give no guarantee that members will be active on the server or that they will stay. <br />
- If the pull bot is kicked mid-process, we will not start a new pull.<br />
- If security systems intervene such as Anti Raid Bots or AutoMod, we will not start a new pull.<br /><br />


<strong>Refund TOS:</strong><br />
- After receiving the service/product we do not give and offer any refund!<br /><br />

<strong>Feedback TOS:</strong><br />
- The buyer is obliged to give a rating. Otherwise, the product may be confiscated. This is not a scam but serves the fairness and growth of our business. <br />
- 30 minutes to vouch for us or warranty revoke and we will not do anything if something happens to your product.<br /><br />

<strong>Delivery TOS:</strong><br />
- If a delivery should not be delivered immediately, the solution is only to wait! The nagging or constant inquiries can lead to a loss of product. It is not meant to be evil, but who does not listen must learn it differently.<br /><br />

<strong>Method Terms:</strong><br />
- We do not offer refunds on the purchase of methods. In case something does not work. All methods have been tested by us, partly invented by us and all of them worked at the time. It can always happen that some steps do not work, but we are always working on solutions and offer no guarantee.<br /><br />


<em>When a purchase is made, our TOS are automatically accepted, those who join our Discord server also accept and confirm our TOS. With every purchase you will be asked again for a manual confirmation and agreement of the TOS. Ignorance does not protect and does not change the fact. Our TOS are subject to change at any time without notice.</em>
  </div>
  
  


	 </div>  
	 
	  <div class="mb_8 pb_8"></div>
	 
	 
</section>

   
    

 <footer class="bg_tertiary" data-aos="fade-up">
 <div class="container pt_8 pb_8">
  
  <div class="flex_container">
     <div data-width="30%" class="color_neutral">
	     <div class="color_secondary text_large weight_semibold mb_4 logo"><img data-width="200px" src="images/logo.png?t=1724163956" /></div>
		    We are your professional contact since 2022 for cheap and very fast Discord services & co. Discover us now!
	 </div>
	 <div data-width="30%"></div>
     <div data-width="20%">
	 
	 <div class="weight_semibold">Resources</div>
	 <a href="#features" class="block mt_2 mb_2"><span class="color_neutral">Features</span></a>
	  <a href="#faq" class="block mt_2 mb_2"><span class="color_neutral">FAQ</span></a>
	 <a href="#products" class="block mt_2 mb_2"><span class="color_neutral">Products</span></a>
	 <a href="https://boost4u.cc/discord" target="_blank" class="block mt_2 mb_2"><span class="color_neutral">Discord</span></a>
	
	 
	 </div>
	   <div data-width="20%">
     <div class="weight_semibold">Other</div>
	 <a href="tos.php" class="block mt_2 mb_2"><span class="color_neutral">Terms of service</span></a>
	 <a href="#top" class="block mt_2 mb_2"><span class="color_neutral">Return to top</span></a>
	 <a href="#features" class="block mt_2 mb_2"><span class="color_neutral">Feedbacks</span></a>

	 
	 </div>
    
  </div>
  
		   
			
			
	
		
	
		  
		
				  
		</div>
   
   </div>
 
 
 <div class="mt_4 pt_4 border pb_4 border_dark_gray container">
   © 2024 <span class="theme_text_gradient">Boost4u</span>. All rights reserved.<br />
   We are not affiliate with Discord.com. 
   

 
 </div>
 </div>
 </footer>



   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
   <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

<script>
  AOS.init();
</script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.js"></script>
	<script src="general.js?t=1724163956"></script>





<script>(function(){function c(){var b=a.contentDocument||a.contentWindow.document;if(b){var d=b.createElement('script');d.innerHTML="window.__CF$cv$params={r:'8b630e393c9d9c8e',t:'MTcyNDE2Mzk1Ni4wMDAwMDA='};var a=document.createElement('script');a.nonce='';a.src='/cdn-cgi/challenge-platform/scripts/jsd/main.js';document.getElementsByTagName('head')[0].appendChild(a);";b.getElementsByTagName('head')[0].appendChild(d)}}if(document.body){var a=document.createElement('iframe');a.height=1;a.width=1;a.style.position='absolute';a.style.top=0;a.style.left=0;a.style.border='none';a.style.visibility='hidden';document.body.appendChild(a);if('loading'!==document.readyState)c();else if(window.addEventListener)document.addEventListener('DOMContentLoaded',c);else{var e=document.onreadystatechange||function(){};document.onreadystatechange=function(b){e(b);'loading'!==document.readyState&&(document.onreadystatechange=e,c())}}}})();</script></body>

</html>

  </body>
</html>
